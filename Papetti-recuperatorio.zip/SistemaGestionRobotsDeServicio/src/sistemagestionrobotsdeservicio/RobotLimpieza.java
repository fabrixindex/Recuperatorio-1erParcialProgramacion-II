package sistemagestionrobotsdeservicio;


public class RobotLimpieza extends Robot implements Ejecutable {
    
    private static final int DIVISOR_SUPERFICIE = 10;
    private static final int BASE_CONSUMO = 5;
    
    private final int superficie;

    public RobotLimpieza(String numeroSerie, String fabricante, Prioridad prioridad, int bateria, int superficie) {
        super(numeroSerie, fabricante, prioridad, bateria);
        this.superficie = validarPositivo(superficie, "La superficie");
    }

    public int getSuperficie() {
        return superficie;
    }
    
    @Override
    public int calcularConsumo() {
        return superficie / DIVISOR_SUPERFICIE + BASE_CONSUMO;
    }
    
    @Override
    public String ejecutarServicio() {
        consumirBateria();
        return "Servicio de limpieza " + getNumeroSerie() + " ejecutado. Bateria restante: " + getBateria() + "%.";
    }
    
    @Override
    public String toString() {
        return "RobotLimpieza [" + datosBase() + ", superficie=" + superficie + "]";
    }
     
    
    
}
