
package sistemagestionrobotsdeservicio;

/**
 *
 * Robot de reparto
 * 
 */

public class RobotReparto extends Robot implements Ejecutable, Diagnosticable {
    
    private static final int FACTOR_CARGA = 3;
    private static final int BASE_CONSUMO = 4;
    
    private final int capacidadCarga;

    public RobotReparto(String numeroSerie, String fabricante, Prioridad prioridad, int bateria, int capacidadCarga) {
        super(numeroSerie, fabricante, prioridad, bateria);
        this.capacidadCarga = validarPositivo(capacidadCarga, "La capacidad de carga");
    }

    public int getCapacidadCarga() {
        return capacidadCarga;
    }

    @Override
    public int calcularConsumo() {
        return capacidadCarga * FACTOR_CARGA + BASE_CONSUMO;
    }

    @Override
    public String ejecutarServicio() {
        consumirBateria();
        return "Servicio de reparto " + getNumeroSerie() + " ejecutado. Bateria restante: " + getBateria() + "%.";
    }

    @Override
    public String generarDiagnostico() {
        return "Dagnostico de reparto " + getNumeroSerie() + ": capacidad de " + capacidadCarga + " Kg.";
    }
    
    @Override
    public String toString() {
        return "RobotReparto [" + datosBase() + ", carga=" + capacidadCarga + "]";
    }
     
    
    
}
