package sistemagestionrobotsdeservicio;

/**
 *
 * Robot capaz de ejecutar servicios
 * 
 */

public interface Ejecutable {
    
    String ejecutarServicio();
    
}
