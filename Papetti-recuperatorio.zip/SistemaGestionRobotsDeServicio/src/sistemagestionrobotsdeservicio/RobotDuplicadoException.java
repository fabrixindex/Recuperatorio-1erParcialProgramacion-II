package sistemagestionrobotsdeservicio;

/**
 *
 * Se lanza cuando se intenta agregar un robot y ya existe en la flota
 */

public class RobotDuplicadoException extends Exception {
    
    public RobotDuplicadoException(String numeroSerie, String fabricante) {
        super("Ya existe un robot con serie " + numeroSerie + " y fabricante " + fabricante + ".");
    }
}
