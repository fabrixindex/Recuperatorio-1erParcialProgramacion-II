package sistemagestionrobotsdeservicio;

/**
 *
 * Robot capaz de generar un diagnostico
 * 
 */

public interface Diagnosticable {
    
    String generarDiagnostico();
}
