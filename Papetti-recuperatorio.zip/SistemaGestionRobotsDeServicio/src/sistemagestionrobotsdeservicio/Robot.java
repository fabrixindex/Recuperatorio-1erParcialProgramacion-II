package sistemagestionrobotsdeservicio;

import java.util.Objects;

/**
 *
 * Robot de servicio
 * 
 */

public abstract class Robot {
    private static final int BATERIA_MINIMA = 0;
    private static final int BATERIA_MAXIMA = 100;
    
    private final String numeroSerie;
    private final String fabricante;
    private final Prioridad prioridad;
    private int bateria; 
    
    public Robot(String numeroSerie, String fabricante, Prioridad prioridad, int bateria) {
        this.numeroSerie = validarTexto(numeroSerie, "El numero de serie");
        this.fabricante = validarTexto(fabricante, "El fabricante");
        this.prioridad = validarPrioridad(prioridad);
        this.bateria = validarBateria(bateria);
    }
    
    private static Prioridad validarPrioridad(Prioridad prioridad) {
        if (prioridad == null) { 
            throw new IllegalArgumentException("La prioridad no puede ser nula");
        }
        return prioridad;
    }
    
    private static int validarBateria(int bateria) {
        if (bateria < BATERIA_MINIMA || bateria > BATERIA_MAXIMA) {
            throw new IllegalArgumentException("La bateria debe estar entre " + BATERIA_MINIMA + " y " + BATERIA_MAXIMA);
        }
        return bateria;
    }
    
    protected static String validarTexto(String valor, String campo) {
        if (valor == null || valor.isBlank()) {
            throw new IllegalArgumentException(campo + " no puede ser nulo ni estar en blanco");
        }
        return valor;
    }
    
    protected static int validarPositivo(int valor, String campo) {
        if (valor <= 0) {
            throw new IllegalArgumentException(campo + " debe ser un entero mayor que cero");
        }
        return valor;
    }

    public String getNumeroSerie() {
        return numeroSerie;
    }

    public String getFabricante() {
        return fabricante;
    }

    public Prioridad getPrioridad() {
        return prioridad;
    }

    public int getBateria() {
        return bateria;
    }
    
    public abstract int calcularConsumo();
    
    protected void consumirBateria() {
        int consumo = calcularConsumo();
        if (bateria < consumo) {
            throw new IllegalStateException("Bateria insuficiente");
        }
        bateria -= consumo;
    }
    
    protected String datosBase() {
        return "Serie=" + numeroSerie + ", fabricante=" + fabricante + ", prioridad=" + prioridad + ", bateria=" + bateria;
    }
    
    @Override
    public boolean equals(Object o) {
        if(this == o) return true;
        if(!(o instanceof Robot)) return false;
        Robot otro = (Robot) o;
        return numeroSerie.equals(otro.numeroSerie) && fabricante.equals(otro.fabricante);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(numeroSerie, fabricante);
    }
    
}
