package sistemagestionrobotsdeservicio;

import java.util.List;
import java.util.ArrayList;

/**
 *
 * Flota de robots de la empresa
 * 
 */

public class FlotaRobots {
    
    private final String nombre;
    private final List<Robot> robots;

    public FlotaRobots(String nombre) {
        this.nombre = validarNombre(nombre);
        this.robots = new ArrayList<>();
    }
    
    private static String validarNombre(String nombre) {
        if (nombre == null || nombre.isBlank()) {
            throw new IllegalArgumentException("El nombre de la flota no puede ser nulo ni estar en blanco");
        }
        return nombre;
    }

    public String getNombre() {
        return nombre;
    }
    
    public void agregarRobot(Robot robot) throws RobotDuplicadoException {
        if (robot == null) {
            throw new IllegalArgumentException("El robot no puede ser nulo");
        }
        if (robots.contains(robot)) {
            throw new RobotDuplicadoException(robot.getNumeroSerie(), robot.getFabricante());
        }
        robots.add(robot);
    }

    public List<Robot> obtenerRobots() {
        return new ArrayList<>(robots);
    }
    
    public List<Robot> filtrarPorPrioridad(Prioridad prioridad) {
        if (prioridad == null) {
            throw new IllegalArgumentException("La prioridad no puede ser nula");
        }
        List<Robot> resultado = new ArrayList<>();
        for (Robot r : robots) {
            if (r.getPrioridad() == prioridad) {
                resultado.add(r);
            }
        }
        return resultado;
    }
    
    public List <Robot> obtenerRobotsConConsumoMaximo(int maximo) {
        List<Robot> resultado = new ArrayList<>();
        for (Robot r : robots) {
            if (r.calcularConsumo() <= maximo) {
                resultado.add(r);
            }
        }
        return resultado;
    }
    
    
}
