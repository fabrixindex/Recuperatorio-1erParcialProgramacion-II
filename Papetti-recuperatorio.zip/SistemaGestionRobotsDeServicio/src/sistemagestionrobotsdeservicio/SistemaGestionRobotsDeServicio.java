package sistemagestionrobotsdeservicio;

import java.util.List;


public class SistemaGestionRobotsDeServicio {

    public static void main(String[] args) {
        
        FlotaRobots flota = new FlotaRobots("TecnoAsistencia");
        
        try {
            flota.agregarRobot(new RobotLimpieza("RL-10", "Nova", Prioridad.ALTA, 60, 80)); 
            flota.agregarRobot(new RobotVigilancia("RV-20", "Orbis", Prioridad.MEDIA, 75, 3)); 
            flota.agregarRobot(new RobotReparto("RR-30", "Nova", Prioridad.BAJA, 40, 5)); 
            flota.agregarRobot(new RobotReparto("RR-40", "Orbis", Prioridad.ALTA, 15, 4)); 
            flota.agregarRobot(new RobotVigilancia("RL-10", "Nova", Prioridad.BAJA, 90, 2));
        } catch (RobotDuplicadoException e) {
            System.out.println("No se pudo agregar: " + e.getMessage());
            
        }

        System.out.println("Robots registrados:");
        mostrarRobots(flota.obtenerRobots());
        
        System.out.println("\nEjecución de servicios:");
        ejecutarServicios(flota.obtenerRobots());
        
        System.out.println("\nDiagnósticos:");
        generarDiagnosticos(flota.obtenerRobots());
        
        System.out.println("\nRobots de prioridad ALTA:");
        mostrarRobots(flota.filtrarPorPrioridad(Prioridad.ALTA));
        
        System.out.println("\nRobots con consumo máximo de 18:");
        mostrarRobots(flota.obtenerRobotsConConsumoMaximo(18));
        
        System.out.println("\nConsumos actuales:");
        mostrarConsumos(flota.obtenerRobots());
}
    
private static void mostrarRobots(List<Robot> robots) {
    for (Robot r: robots) {
        System.out.println(r);
    }
}

private static void ejecutarServicios(List<Robot> robots) {
    for (Robot r : robots) {
        if (r instanceof Ejecutable) {
            try {
                System.out.println(((Ejecutable) r).ejecutarServicio());
            } catch (IllegalStateException e) {
                System.out.println("No se pudo ejecutar " + r.getNumeroSerie() + ": " + e.getMessage() + ".");
            }
        } else {
            System.out.println("El robor " + r.getNumeroSerie() + " no ejecuta servicios.");
        }
    }
}

private static void generarDiagnosticos(List<Robot> robots) {
    for (Robot r: robots) {
        if (r instanceof Diagnosticable) {
        System.out.println(((Diagnosticable) r).generarDiagnostico());
    } else{
            System.out.println("El robot " + r.getNumeroSerie() + " no genera diagnostico");
            }
    }
}
private static void mostrarConsumos(List<Robot> robots) {
        for (Robot r : robots) {
            System.out.println(r.getNumeroSerie() + ": " + r.calcularConsumo() + " puntos de bateria por operacion.");
        }
    }
    
}
