package sistemagestionrobotsdeservicio;

/**
 *
 * Prioridad de servicio de un robot.
 * 
 */

public enum Prioridad {
    BAJA,
    MEDIA,
    ALTA
}
