package sistemagestionrobotsdeservicio;

/**
 *
 * Robot de vigilancia
 * 
 */

public class RobotVigilancia extends Robot implements Diagnosticable {
    
    private static final int FACTOR_CAMARAS = 4;
    private static final int BASE_CONSUMO = 6;
    
    private final int camaras;

    public RobotVigilancia(String numeroSerie, String fabricante, Prioridad prioridad, int bateria, int camaras) {
        super(numeroSerie, fabricante, prioridad, bateria);
        this.camaras = validarPositivo(camaras, "La cantidad de camaras");
    }

    public int getCamaras() {
        return camaras;
    }

    @Override
    public int calcularConsumo() {
        return camaras * FACTOR_CAMARAS + BASE_CONSUMO;
    }

    @Override
    public String generarDiagnostico() {
        return "Diagnostico de vigilancia " + getNumeroSerie() + ": " + camaras + " camaras operativas.";
    }
    
    @Override
    public String toString() {
        return "RobotVigilianza [" + datosBase() + ", camaras=" + camaras + "]";
    }
    
}
